import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TranslatePipe } from '../../i18n/i18n.service';
import { SeoService } from '../../services/seo.service';
import { SoloProgressService } from '../../services/solo-progress.service';
import { AnalyticsService } from '../../services/analytics.service';
import {
  GameModeChoice,
  ModePickerComponent
} from '../../components/mode-picker/mode-picker.component';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, TranslatePipe, ModePickerComponent],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent implements OnInit {
  modePickerOpen = false;

  constructor(
    private router: Router,
    private seo: SeoService,
    public progress: SoloProgressService,
    private analytics: AnalyticsService
  ) {}

  ngOnInit(): void {
    this.seo.apply({
      titleKey: 'seo.home.title',
      descKey: 'seo.home.desc',
      canonicalPath: '/'
    });
    this.seo.applyGameJsonLd();
  }

  /** Apre el modal con las 3 opciones */
  openModePicker(): void {
    this.analytics.event('cta_click', {
      cta: 'play_now',
      has_progress: this.hasProgress
    });
    this.modePickerOpen = true;
  }

  closeModePicker(): void {
    this.modePickerOpen = false;
  }

  onModePicked(choice: GameModeChoice): void {
    this.modePickerOpen = false;
    this.analytics.event('mode_picked', { mode: choice });
    if (choice === 'solo') {
      if (this.hasProgress) {
        this.router.navigate(['/levels']);
      } else {
        this.router.navigate(['/solo', 1]);
      }
    } else if (choice === 'create') {
      this.router.navigate(['/create']);
    } else if (choice === 'join') {
      this.router.navigate(['/join']);
    }
  }

  goLevels(): void {
    this.analytics.event('cta_click', { cta: 'all_levels' });
    this.router.navigate(['/levels']);
  }
  continuePlaying(): void {
    this.analytics.event('cta_click', {
      cta: 'continue',
      level_id: this.nextLevelId
    });
    this.router.navigate(['/solo', this.nextLevelId]);
  }
  goHowToPlay(): void {
    this.analytics.event('cta_click', { cta: 'how_to_play' });
    this.router.navigate(['/how-to-play']);
  }
  goLeaderboard(): void {
    this.analytics.event('cta_click', { cta: 'leaderboard' });
    this.router.navigate(['/leaderboard']);
  }

  get hasProgress(): boolean {
    return this.progress.current.totalStars > 0
      || this.progress.current.highestLevelUnlocked > 1;
  }

  get nextLevelId(): number {
    const next = this.progress.current.highestLevelUnlocked;
    return Math.min(next, this.progress.levels.length);
  }
}
